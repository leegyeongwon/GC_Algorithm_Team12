package Testing_package;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class RSA extends JFrame{
	private GUI_1 main;
	
	
	private JButton btnRsa;
	private JButton btnInit;
	private JPasswordField passText;
	private boolean bRsaCheck;
	
	public static void main(String[] args) {
		
	}

	public RSA() {
		
	// setting
    setTitle("login");
    setSize(280, 150);
    setResizable(false);
    setLocation(800, 450);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
   
    // panel
    JPanel panel = new JPanel();
    placeLoginPanel(panel);
   
   
    // add
    add(panel);
   
    // visiible
    setVisible(true);
}

public void placeLoginPanel(JPanel panel){
   
    JLabel passLabel = new JLabel("Pass");
    passLabel.setBounds(10, 40, 80, 25);
    panel.add(passLabel);
   
    passText = new JPasswordField(20);
    passText.setBounds(100, 40, 160, 25);
    panel.add(passText);
    passText.addActionListener(new ActionListener() {          
        @Override
        public void actionPerformed(ActionEvent e) {
            isLoginCheck();        
        }
    });
   
    btnInit = new JButton("Reset");
    btnInit.setBounds(10, 80, 100, 25);
    panel.add(btnInit);
    btnInit.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            passText.setText("");
        }
    });
   
    btnRsa = new JButton("Login");
    btnRsa.setBounds(160, 80, 100, 25);
    panel.add(btnRsa);
    btnRsa.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            isLoginCheck();
        }
    });
}

public void isLoginCheck(){
    if( new String(passText.getPassword()).equals("1234")){
        JOptionPane.showMessageDialog(null, "Success");
        bRsaCheck = true;
       
        // 로그인 성공이라면 매니져창 뛰우기
        if(isLogin()){
            main.showFrameTest(); // 메인창 메소드를 이용해 창뛰우기
        }                  
    }else{
        JOptionPane.showMessageDialog(null, "Wrong Key!");
    }
}


// mainProcess와 연동
public void setMain(GUI_1 main) {
    this.main = main;
}


public boolean isLogin() {     
    return bRsaCheck;
}

}

	

